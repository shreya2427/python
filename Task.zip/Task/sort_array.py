#sort array [5,2,8,1,6,7,9]

array = [5,2,8,1,6,7,9]
array.sort()
print(array)

