#1. return first repeat occurence Element index
# arr = [10,4,5,3,5,3,6]
# -> output = 5

arr = [10,4,5,3,5,3,6]
for i in arr:
    c = arr.count(i)
    if c > 1:
        print(i)
        break
        
