#get Unique Characters 'Hello112234Maansi'


char = 'Hello112234Maansi'
new_char = []
for i in char:
    if i not in new_char:
        new_char.append(i)
unique_char = ''.join(new_char)
print(unique_char)
