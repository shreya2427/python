from django.shortcuts import render
from . models import Student
from django.http import HttpResponse

# Create your views here.
def displayallstudentdata(request):
	allstudent = Student.objects.all()
	return render(request,'Studapp/DisplayData.html',context = {"as":allstudent})


def addrecord(request):
	return render(request,'Studapp/AddStudent.html')

def insertrecord(request):
	n = request.GET["nm"]
	b = request.GET["branch"]
	s = Student(nm=n,branch=b)
	s.save()
	return HttpResponse(displayallstudentdata(request))

def deleterecord(request,sid):
	s = Student.objects.filter(id=sid)
	s.delete()
	return HttpResponse(displayallstudentdata(request))