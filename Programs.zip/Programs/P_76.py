#Python Program to Split list into Smaller Chunks

l = ["Python", "Program"," to","Split" ,"list" ,"into" ,"Smaller", "Chunks","is","necessary"]
start = 0
end = 9

for i in range(start,end,4):
    print(l[i:i+4])