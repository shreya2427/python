#Python Program to Replace all Instances of a Character in a String
str = "An apple A day keeps doctor Away."
 
# replacing character a with $ sign
str = str.replace('a', '$')
str = str.replace('a'.upper(),'$')
print("Modified string : ",str)
