#Python Program to Create Dictionary in Different Ways

dic = {
    "model":"Sonet",
    "color":"blue"
}
print(dic)

car = {1:"ciaz",2:"creta",3:"harrier"}
print(car)

#using fromkeys
listofStrings = ["Hello", "hi", "there", "at", "this"]
wordFrequency = dict.fromkeys(listofStrings,0 )
print(wordFrequency)

