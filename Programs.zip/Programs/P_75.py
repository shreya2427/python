#Python Program to Get Random Item From an list
import random

mylist = [101,102,103,104,105]

print(random.choice(mylist))