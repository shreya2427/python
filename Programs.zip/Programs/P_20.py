#Python Program to Find LCM

n = int(input("Enter no :-"))
m = int(input("Enter no :-"))

for i in range(1,(n*m)+1):
    if i % n == 0 and i % m == 0:
        print(f"{n} and {m} LCM is {i}")
        break



