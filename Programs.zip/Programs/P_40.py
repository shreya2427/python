# Python Program to Loop Through an Dictionary

dic = {
    "model":"Sonet",
    "color":"blue"
}
print(dic)

for x,y in dic.items():
    print(x,y)