# Python Program to Count the Number of Keys/Properties in an Dictionary
