#Python Program to Find the Factors of a Number
n = int(input("Enter No:-"))
for i in range(1,n+1):
    if n%i ==0:
        print(i)