#Python Program to Check if the Numbers Have Same Last Digit
a = input(["Enter No:-"])
aa = a[::-1]
b = input(["Enter No:-"])
bb = b[::-1]
c = input(["Enter No:-"])
cc = c[::-1]

if aa[0] == bb[0] == cc[0]:
    print("Yes,Last Digit is same")
else:
    print("Not Same")

