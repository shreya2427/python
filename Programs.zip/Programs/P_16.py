#Python Program to Make a Simple Calculator

s = int(input("Enter No:-"))
e = int(input("Enter No:-"))

print("1 is for Add,2 is for Sub,3 is for Multiplication,4 is for division")
Choice = int(input("Enter Choice between 1 to 4:-"))

for i in range(0,Choice):
    if Choice < 1 or Choice > 4:
        print("Invalid NO Enter Number between 1 to 4")
        Choice = int(input("Enter Choice between 1 to 4:-"))

if Choice == 1:
    sum = s + e
    print(f"{s} + {e} is {sum}")

elif Choice == 2:
    sub = s - e
    print(f"{s} - {e} is {sub}")

elif Choice == 3:
    mul = s * e
    print(f"{s} * {e} is {mul}")

elif Choice == 4:
    div = s // e
    print(f"{s} / {e} is {div}")
