#Python Program to Check if An List Contains a Specified Value
l = ['apple','mango','banana','cherry','chikoo','kiwi']
print(l)


if  "kiwi" in l:
    print("yes")
else:
    print("No")