#Python Program to Sort Words in Alphabetical Order

a =  input("Enter String:-")
b = a.split()
b.sort()
for i in b:
    print(i)

