#Python Program to Check if a Number is Odd or Even
n = int(input("Enter no:-"))
if n % 2 == 0:
    print("It is Even")
else:
    print("It is odd")