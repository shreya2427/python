#Python Program to Check if a Key Exists in an Dictionary


my_dict = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

if 'key2' in my_dict:
    print("Key exists in the dictionary.")
else:
    print("Key does not exist in the dictionary.")