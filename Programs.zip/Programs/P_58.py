#Python Program to Format the Date

import datetime

a = datetime.datetime.now()
print(a.strftime("%d-%m-%y"))