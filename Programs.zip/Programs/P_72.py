#Python Program to Create Two Dimensional List

rows, cols = (3, 3)
arr = [[0,1,2,3,4,5]*cols]*rows
print(arr)