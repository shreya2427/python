#Python Program To Get The Current URL
from selenium import webdriver
driver = webdriver.Chrome()
print (driver.current_url)