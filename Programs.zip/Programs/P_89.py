#Python Program to Get the Dimensions of an Image

# import required module 
from PIL import Image 
  
# get image 
filepath = "/home/think/Downloads/1704879279630.JPEG"
img = Image.open(filepath) 
  
# get width and height 
width = img.width 
height = img.height 
  
# display width and height 
print("The height of the image is: ", height) 
print("The width of the image is: ", width) 