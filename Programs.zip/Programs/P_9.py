#Python Program to Check Prime Number
n = int(input("Enter No:-"))
count = 0
if n>1:
    for i  in range(1,n+1):
        if (n%i) == 0:
            count = count+1
    if count==2:
        print("Number is Prime")
    else:
        print("Not Prime")