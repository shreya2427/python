#Python Program to Check the Number of Occurrences of a Character in the String
count = 0

my_string = "shreyaaa"
my_char = "a"

for i in my_string:
    if i == my_char:
        count += 1

print(count)





