# Python Program to Add Key/Value Pair to an Dictionary
dic = {
    "model":"Sonet",
    "color":"blue"
}
print(dic)

dic["year"]=2020
dic.update({"year":2022})
print(dic)