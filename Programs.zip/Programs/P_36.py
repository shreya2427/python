# Python Program to Remove a Property from an Dictionary
dic = {
    "model":"Sonet",
    "color":"blue"
}
print(dic)

dic.pop("model")
print(dic)