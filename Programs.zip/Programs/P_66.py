#Python Program to Check if An Dictionary is An List

test_dict = {"gfg" : 4, "is" : 10, "best" : 11, "for" : 19, "geeks" : 1}
 
print("The original dictionary is : " + str(test_dict))
 
sub_list = [4, 10, 11, 19, 1]
 
res = list(test_dict.values()) == sub_list
     
print("Are values in order : " + str(res)) 