#Python Program to Convert Date to Number

import datetime

now = datetime.datetime.now()

timestamp = int(now.timestamp())
print(type(timestamp))
print(timestamp)