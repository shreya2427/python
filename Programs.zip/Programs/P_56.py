#Python Program to Display Date and Time
import datetime

a = datetime.datetime.now()
print(a)


