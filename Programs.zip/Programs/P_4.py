#Python Program to Convert Celsius to Fahrenheit  (c*1.8)+32 

celsius = int(input("Enter Celsius:-"))

fah = (celsius*1.8)+32

print(f"The Fahrenheit of the {celsius} is {fah}")