#Python Program to Implement a Queue

class queue:
    def __init__(self):
        self.values=[]
    def queue(self,x):
        self.values.append(x)
    def dequeu(self):
        front =self.values[0]
        self.values=self.values[1:]
        return front
q1 = queue()
q1.queue(10)
q1.queue(20)
q1.queue(30)
print(q1.values)
print(q1.dequeu())

