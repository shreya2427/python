#Python Program to Replace All Line Breaks with space

string = "Hello\nWorld\n"
print(string)
string = string.replace("\n"," ")
print(string)
