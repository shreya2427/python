#Python Program to Check Whether a String Contains a Substring

str1 = 'I love Python Programming'

str2 = 'Python'

str3 = 'Java'

print(f'"{str1}" contains "{str2}" = {str2 in str1}')
print(f'"{str1}" contains "{str2}" = {str2 in str3}')

if str2 in str1:
    print("Yes,Str1 contains str2")
else:
    print("Not Cointains")