#Python Program to Compare Two Strings
string1 = "hello"
string2 = "hello"

if string1 == string2:
    print("The strings are equal.")
else:
    print("The strings are not equal.")