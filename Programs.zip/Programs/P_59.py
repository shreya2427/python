#Python Program to Display Current Date
import datetime

a = datetime.date.today()
print(a)