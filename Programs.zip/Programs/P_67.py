#Python Program to Empty an List
l = ['apple','mango','banana','cherry','chikoo','kiwi']
print(l)
l.clear()
print(l)