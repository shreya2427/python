#Python Program to Sort List of Objects by Property Values

class Student:
    def __init__(self, name, age, height):
        self.name = name
        self.age = age
        self.height = height
students = [
Student("Tom", 12, 145),
Student("Ben", 10, 135),
Student("Alan", 9, 130),
Student("Rose", 10, 139),
Student("Bella", 9, 125),
Student("Monica", 12, 149)
]
sorted_student = sorted(students, key=lambda student: (student.age, student.height))
for student in sorted_student:
    print(student.name, student.age, student.height)


