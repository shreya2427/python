#Python Program to Find HCF or GCD

n = int(input("Enter no :-"))
m = int(input("Enter no :-"))
hcf = 1
for i in range(1,n):
    if n % i == 0 and m % i == 0:
        hcf = i
print(f"{n} and {m} HCF is {hcf}")