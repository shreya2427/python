#Python Program to Find the Largest Among Three Numbers

a = int(input("Enter no :-"))
b = int(input("Enter no :-"))
c = int(input("Enter no :-"))

d = [a,b,c]
d.sort(reverse=True)
print(d[0])