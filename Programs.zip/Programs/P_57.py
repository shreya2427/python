#Python Program to Check Leap Year

n = int(input("Enter Year:-"))

if (n % 400) == 0 and (n % 100) == 0:
    print(f"{n} is a Leap Year")
elif (n % 4) == 0 and (n % 100) != 0:
    print(f"{n} is a Leap Year")
else:
    print(f"{n} is not a Leap Year")