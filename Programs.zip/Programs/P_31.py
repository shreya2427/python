#Python Program to Reverse a String
a = input("Enter Value:-")
b = a[::-1]
print(b)