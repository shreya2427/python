#Python Program to Extract Given Property Values from Objects as List

l=["10","11","12","13","14","15"]

print([l[j] for j in (0,2,5)])


