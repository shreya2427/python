#Python Program to Remove Duplicates From List

duplicate = [2, 4, 10, 20, 5, 2, 20, 4]

def Remove(duplicate):
    final_list = []
    for num in duplicate:
        if num not in final_list:
            final_list.append(num)
    return final_list
     
print(Remove(duplicate))