# Python Program to Generate Random String
import random

mylist = ["apple", "banana", "cherry","mango","chikoo"]

print(random.choice(mylist))