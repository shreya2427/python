# Python Program to Copy a Dictionary
dic = {
    "model":"Sonet",
    "color":"blue"
}
print(dic)

car = dic.copy()
print(car)