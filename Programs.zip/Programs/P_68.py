#Python Program to Add Element to Start of an List
l = ['apple','mango','banana','cherry','chikoo','kiwi']

l.insert(0,"orange")
print(l)
