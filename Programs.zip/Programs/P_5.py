#Python Program to Generate a Random Number
import random

a = random.randint(1,100000)
print(a)