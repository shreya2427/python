#Python Program to Check Whether a String is Palindrome or Not

a = input("Enter value:-")
if a == a[::-1]:
    print("It is Palindrom")
else:
    print("Not Palindrom")