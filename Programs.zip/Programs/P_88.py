#Python Program to Pass a Function as Parameter

def my_function(fname):  
    print(fname + " Id")  
my_function("Emil")  
my_function("Phone")  