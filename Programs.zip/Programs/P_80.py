#Python Program to Generate a Random Number Between Two Numbers
import random

a = random.randint(100,200)
print(a)