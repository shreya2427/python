# Python Program to Convert Dictionarys to Strings
dic = {
    "color":"red",
    "edition":"old"
}
print(dic)

s = str(dic)
print(type(s))
print(s)