#Python Program To Check If A Variable Is 

var = None

if var is None:
    print("Variable is empty")
else:
    print(var)