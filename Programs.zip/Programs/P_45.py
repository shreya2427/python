# Python Program to Create Multiline Strings
a = """
Multiline Strings. You can assign a multiline string 
to a variable by using three quotes: ExampleGet your 
own Python Server. You can use three 
"""
print(a)