#Python Program to Check if a Number is Float or Integer

number = 12

check_int = isinstance(number, int)
if check_int == False:
    print(f'float number {number}')
else:
    print(f'Int number {number}')

    
print(check_int)
