#Python Program to Find ASCII Value of Character (ord() function is used to get the int value)
c = str(input("Enter String:-"))
print("The ASCII value of '" + c + "' is", ord(c))