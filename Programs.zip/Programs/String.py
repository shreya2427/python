string =  "ambcambdmd"

# output: {a :2, b: 2, c: 1,m: 3,d: 2 }

a = {}
for i in string:
    if i in a:
        a[i] += 1
    else:
        a[i] = 1
print(a)