#Python Program to Merge Two Lists and Remove Duplicate Items
l = [1,2,3,4,5]
m = [3,4,5,6,7]
l.extend(m)
print(l)

def Remove(l):
    new_l = []
    for i in l:
        if i not in new_l :
            new_l.append(i)
    return new_l
print(Remove(l))

