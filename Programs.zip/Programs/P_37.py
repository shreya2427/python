# Python Program to Check Whether a String Starts and Ends With Certain Characters
# ^ start with $ ends with  
# s = input("Enter string:-").lower()
# a = s[::-1]
# if s[0] == a[0]:
#     print("Yes,Start and End charater is same")
# else:
#     print("Not Same")

import re

string=input("Enter string:-")

a = r'^[a-z]$|^([a-z])'
if(re.search(a,string)):
  print("Valid String")
else:
  print("Invalid string")