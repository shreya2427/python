# Python Program to Check if a String Starts With Another String

s = 'Make it work, make it right, make it fast'
result = s.startswith(('Make','make'))
result1 = s.endswith(('fast','Fast'))
print(result)
print(result1)