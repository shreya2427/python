#Python Program to Find Armstrong Number in an Interval

n = int(input("Enter start num:-"))
e = int(input("Enter  end no :-"))

for i in range(n,e+1):
    order = len(str(i))
    sum = 0

    temp = i
    while(temp>0):
        digit = temp % 10
        sum += digit ** order
        temp //= 10

    if i == sum:
        print(i)
        
