#1	Python Program to Swap Two Variables

a = 10
b = 20
print(a)
print(b)

a,b = b,a

print(a)
print(b)