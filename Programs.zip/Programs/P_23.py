#Python Program to Guess a Random Number
import random

n = int(input("Enter Number:-"))

a = random.randint(1,100)
print(a)
if n == a:
    print("Guess is correct")
else:
    print("Not Correct")