#Python Program to Insert Item in an List
l = ['apple','mango','banana','cherry','chikoo','kiwi']
print(l)
l.append("orange")
print(l)
