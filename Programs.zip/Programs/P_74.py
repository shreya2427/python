#Python Program to Get Random Item From an List
import random

mylist = ["apple", "banana", "cherry","mango","chikoo","orange"]

print(random.choice(mylist))
