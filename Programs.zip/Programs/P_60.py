#Python Program to Compare The Value of Two Dates

import datetime
 
# date in yyyy/mm/dd format
d1 = datetime.datetime(2024, 5, 3)
d2 = datetime.datetime(2024, 6, 1)
 
print("d1 is greater than d2 : ", d1 > d2)
print("d1 is less than d2 : ", d1 < d2)
print("d1 is not equal to d2 : ", d1 != d2)