#Python Program to Convert Kilometers to Miles
#0.621371

km = int(input("Enter value in km :-"))

miles = 0.621371 * km

print(f"The Miles for the {km} km is {miles}")