#Python Program to Append an Dictionary to An List
l=[]
stud = {
    1:'ram',
    2:'shyam',
    3:'kishan'
}
l.append(stud)
print(l)