a=[{
    "name" : "mihir",
    "data" : []
},
{
    "name" : "hiren",
    "data" : []
},
{
    "name" : "shashank",
    "data" : []
},
{
    "name" : "vasudha",
    "data" : []
}
]


b = {
    "mihir" : {"age" : 23},
    "hiren" : {"age" : 21},
    "vasudha" : {"age" : 20},

}
# print(a)

for i in a:
    name = i["name"]
    #print(name)
    if name in b :
        #print(b[name])
        i["data"].append(b[name])
    else:
        print(name)
print(a)
    