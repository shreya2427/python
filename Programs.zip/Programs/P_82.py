#Python Program to Validate An Email Address

import re

emial_id = input("Enter You Email ID:-")

pattern = "^[a-z 0-9]+[\.]?[a-z 0-9]+[@]\w+[.]\w{2,3}$"

if re.search(pattern,emial_id):
    print(f"{emial_id} is Valid")
else:
    print(f"{emial_id} is Not Valid")