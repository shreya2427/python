#Python Program to Merge Property of Two Dictionarys
dic = {
    "model":"Sonet",
    "color":"blue"
}
print(dic)

car = {1:"ciaz",
       2:"creta",
       3:"harrier"}
print(car)

dic.update(car)
print(dic)