#Python Program to Remove All Whitespaces From a Text
s = "    hello world  python   django   framework "
a = "".join(s.strip())
print(a)