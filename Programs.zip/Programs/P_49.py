# Python Program to Trim a String
greeting = "     Hello!  "

print(greeting.strip(),"How are you?")

