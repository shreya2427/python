#Python Program to Find Sum of Natural Numbers Using Recursion

def nns(n):
    if n <= 0 :
        return n 
    else:
        return(n)+nns(n-1)
    
n = int(input("Enter No:-"))
if n == 0 :
    print("0 is not a natural number")
else:
    print(nns(n))