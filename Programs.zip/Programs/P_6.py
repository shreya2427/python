#Python Program to Check if a number is Positive, Negative, or Zero
n = int(input("Enter no:-"))
if n <  0:
    print(f"{n} is Negative")
elif n > 1:
    print(f"{n} is Positive")
else:
    print(f"{n} is Zero")
