#Python Program to Find the Sum of Natural Numbers

n = int(input("Enter Natural num :-"))
sum = 0
if n < 0:
    print("Enter Positive no:-")
else:
    for i in range(1,n+1):
        sum = sum+i
    print(sum)