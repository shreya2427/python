#Python Program to Find the Factorial of a Number

num = 1
fac = int(input("Enter No:-"))

if fac < 0:
    print("Factorial of less than 0 does not exist")
elif fac == 0:
    print("Factorial of 0 is 1")
else:
    for i in range(1,fac+1):
        num = num*i
    print(f"Factorial of {fac} is {num}")
