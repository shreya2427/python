# Python Program to Convert the First Letter of a String into UpperCase

str = input("Enter String:-").lower()
a = str.title()
print(a)