#Python Program to Display the Multiplication Table
n  = int(input("Enter No:-"))

for  i in range(1,11):
    print(f"{n} x {i} = {n*i}")