#Python Program to Get File Extension

import os

f = os.path.splitext("home/think/shreya/notes.txt")
print(f[1])