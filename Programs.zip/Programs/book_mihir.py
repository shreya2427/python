books = [
    { 'title': 'The Catcher in the Rye', 'author': 'J.D. Salinger', 'year': 1951 },
    { 'title': 'To Kill a Mockingbird', 'author': 'Harper Lee', 'year': 1960 },
    { 'title': '1984', 'author': 'George Orwell', 'year': 1949 },
    { 'title': 'The Great Gatsby', 'author': 'F. Scott Fitzgerald', 'year': 1925 },
    {'title': 'I thus health heavy.', 'author': 'Andrew Shaw', 'year': 2005},
    {'title': 'I thus health heavy.', 'author': 'Andrew Shaw', 'year': 2005},
    {'title': 'Language most.', 'author': 'Pamela Harris', 'year': 2014},
    {'title': 'At child customer.', 'author': 'Crystal Smith', 'year': 1978},
    {'title': 'Again son garden.', 'author': 'Lisa Brown', 'year': 1974},
    {'title': 'Those bar himself.', 'author': 'Susan Rodriguez', 'year': 1979},
    {'title': 'Hear business.', 'author': 'Stephanie Jones', 'year': 2016},
    {'title': 'Thus trade stand get.', 'author': 'Pamela Rodriguez', 'year': 1990},
    {'title': 'Both itself me member hot.', 'author': 'Kyle Smith', 'year': 1985},
    {'title': 'Factor memory those ball simply.', 'author': 'Mr. Brian Smith MD', 'year': 1992},
    {'title': 'Country with.', 'author': 'Joe Black', 'year': 2014},
    {'title': 'Our later individual many key.', 'author': 'Stephanie Bell', 'year': 2008},
    {'title': 'Set firm talk.', 'author': 'Leroy Roberson', 'year': 2021},
    {'title': 'Pressure nice probably.', 'author': 'Heidi Frank', 'year': 2009},
    {'title': 'College than may himself.', 'author': 'Charles Rivera', 'year': 2002},
    {'title': 'Our admit then police rich.', 'author': 'James Jones', 'year': 2023},
    {'title': 'Player here.', 'author': 'Kevin Riggs', 'year': 1973},
    {'title': 'Hot they.', 'author': 'Jacob Cross', 'year': 2022},
    {'title': 'Bank these create.', 'author': 'Christopher Thompson', 'year': 1988},
    {'title': 'Western interview late general.', 'author': 'Christopher Thomas', 'year': 2017},
    {'title': 'Quality leg rather.', 'author': 'Evan Beck', 'year': 1979},
    {'title': 'Occur support court you.', 'author': 'David Webster', 'year': 1971},
    {'title': 'Company expect still.', 'author': 'Brad Lewis', 'year': 2021},
    {'title': 'Role fall help attorney then.', 'author': 'Bradley Oneal', 'year': 2020},
    {'title': 'Management together yard.', 'author': 'Molly Sawyer', 'year': 1987},
    {'title': 'Yourself third already resource religious.', 'author': 'Michelle Lopez DVM', 'year': 1980},
    {'title': 'Again have yet.', 'author': 'Darren Robertson', 'year': 1990},
    {'title': 'Rock point special.', 'author': 'Jennifer Chavez', 'year': 1986},
    {'title': 'Wait sing yeah kind.', 'author': 'Anthony Kim', 'year': 1975},
    {'title': 'Difference anyone partner.', 'author': 'Sarah Jones', 'year': 2013},
    {'title': 'Shoulder air significant.', 'author': 'Dana Flores', 'year': 1988},
    {'title': 'Treat take.', 'author': 'Amanda Newman', 'year': 1988},
    {'title': 'Television page stock enter.', 'author': 'Jennifer Chavez', 'year': 1971},
    {'title': 'Official bag about forget however.', 'author': 'George Aguirre', 'year': 2004},
    {'title': 'Without personal health.', 'author': 'Ashley Horn', 'year': 1998},
    {'title': 'Institution friend market.', 'author': 'Michael Dunn', 'year': 1997},
    {'title': 'Nor more just.', 'author': 'Blake Trujillo', 'year': 1991},
    {'title': 'Best relationship receive would.', 'author': 'Christina Payne', 'year': 1986},
    {'title': 'Prevent low write.', 'author': 'Michael Ross', 'year': 2020},
    {'title': 'Street soon keep.', 'author': 'Jennifer Chavez', 'year': 1970},
    {'title': 'Southern attorney leave.', 'author': 'Nicole Johnson', 'year': 2004},
    {'title': 'Parent anything explain establish memory.', 'author': 'Robert Hernandez', 'year': 1996},
    {'title': 'Commercial box computer major dark.', 'author': 'Cynthia Garcia', 'year': 1994},
    {'title': 'Admit central arm.', 'author': 'Jennifer Mayer', 'year': 1975},
    {'title': 'Along go.', 'author': 'Melissa Gilbert', 'year': 1995},
    {'title': 'Huge let wrong little.', 'author': 'Jennifer Chavez', 'year': 1978},
    {'title': 'Policy mission professor.', 'author': 'Tracy Burns', 'year': 1976},
    {'title': 'Loss article at support.', 'author': 'Diana Kane', 'year': 2003},
    {'title': 'Involve hand protect according ask.', 'author': 'Jennifer Chavez', 'year': 1973},
    {'title': 'Feeling step can including child.', 'author': 'Lee Curtis', 'year': 2008},
    {'title': 'Common next next.', 'author': 'Eddie Rogers', 'year': 1999},
    {'title': 'Common next next.', 'author': 'Eddie Rogers', 'year': 1999},
    {'title': 'Common next next.', 'author': 'Eddie Rogers', 'year': 1999},
  
]

# 1: Filter books published after a specific year
# 2: Sort books by publication year in ascending order
# 3: Find the total number of books by each author
# 4: Extract unique authors
# 5: Calculate the average publication year of all books
# 6: Find the most recent book
# 7: Remove duplicates based on the author

# from faker import Faker  
# fake = Faker()
# for i in range(0, 50):  
#     print({'title': fake.sentence(4), 
#           'author': fake.name(),
#           'year':fake.year()})  


#-----1 Filter books published after a specific year
# for i in books:
#     if i['year'] > 2000:
#         print(i)
#---------------------

# specific_year = 2000
# filtered_year = list(filter(lambda x : x['year'] > specific_year,books))
# print(filtered_year)


#-----2-Sort books by publication year in ascending order

# s = sorted(books, key=lambda x: x["year"])
# print(s)

#------Second Method)--------
# sorted_books = []
# n = len(books)
# for i in range(n):
#     for j in range(0, n - i - 1):
#         if books[j]['year'] > books[j + 1]['year']:
#             books[j], books[j + 1] = books[j + 1], books[j]
# sorted_books = books
# print(sorted_books)



#------3 Find the total number of books by each author
# author_details = {}
# for num_book in books:
#     auther = num_book['author']
#     if auther in author_details:
#         author_details[auther] += 1
#     else:
#         author_details[auther] = 1
# print(author_details)



#-----4 Extract unique authors
# a = set()
# for x in books:
#     a.add(x['author'])
# print(a)

#---------(Second Method)----------
# unique_books = {}
# for book_author in books:
#     author = book_author['author']

#     if author not in unique_books:
#         unique_books[author] = book_author

# unique_books_dic = list(unique_books.values())
# print(unique_books_dic)



#------5 Calculate the average publication year of all books
# total_book = 0
# for book in books:
#     total_book += book['year']
#     avg = total_book/len(books)
# print(avg)



#------6 Find the most recent book
# recent_book = sorted(books, key=lambda x: x["year"])
# print(recent_book[-1])



#------7 Remove duplicates based on the author
# new_author = set()
# for x in books:
#     new_author.add(x['author'])
# print(a)
