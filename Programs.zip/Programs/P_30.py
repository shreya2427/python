#Python Program to Replace Characters of a String


string = "Hello World"
new_string = string.replace("Hello", "Good Bye")
 
print(new_string)