#Python Program to Remove Specific Item From an List
l = ['apple','mango','banana','cherry','chikoo','kiwi']
print(l)

l.remove("kiwi")
l.pop(0)
print(l)